#include <stdio.h>

int funkcija (int a){
   return a+1;
}

int g1;
int g2 = 10;
int g3 = 14;
int main(){
   printf("Vrednost g1: %dn", g1);
   printf("Vrednost g2: %dn", g2);
   printf("Vrednost g3: %dn", g3);
   return 0;
}